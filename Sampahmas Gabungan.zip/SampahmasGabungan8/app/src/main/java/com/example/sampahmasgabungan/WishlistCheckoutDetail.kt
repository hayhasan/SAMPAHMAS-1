package com.example.sampahmasgabungan

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class WishlistCheckoutDetail : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_wishlist_checkout_detail)
    }
}