package com.example.sampahmasgabungan

data class TransactionModel(
    val title: String,
    val date: String,
    val amount: String
)
