package com.example.sampahmasgabungan

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class Status_Data_QR_NFC : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_status_data_qr_nfc)
    }
}